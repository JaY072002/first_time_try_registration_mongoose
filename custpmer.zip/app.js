// Establishing server and middleware stuff

const express = require('express');
require('dotenv').config();

const app = express();

app.set('view engine', 'ejs')

app.use(express.urlencoded({ extended: true }))
app.use(express.json());
app.use(express.static('public'))

const userRoute = require('./server/routes/user')
app.use('/', userRoute);




app.listen(5000, () => {
    console.log('Listening on 5000');
})