// database comminucation and rendering page stuff

const database = require('../model/db')
const collection = require('../model/user')
const adminCheck = require('../model/admin')

exports.homePageRender = async (req, res) => {
    res.render('register')
}


// /register route handling
// ('/register)

exports.postData = async (req, res) => {
    try {
        const result = await collection.checkUser(req.body);
        if (result.length == 0) {
            collection.insertData(req.body);
            //render success page of resigetration
            res.send('Data inserted succesffully')

        } else {
            // render failure page 
            res.send('user already exists')
        }
        res.end()

    } catch (err) {
        console.log(err);
    }
}

exports.loginPageRender = async (req, res) => {
    res.render('login');
}

exports.userLogin = async (req, res) => {
    const result = await collection.loginUser(req.body);

    if (result.length == 0) {
        res.send('login failed')
    } else {
        res.send('login successful')
    }
}

exports.adminPage = async (req, res) => {
    res.render('adminPanel')
}

exports.adminPostHandle = async (req, res) => {
    adminCheck(req.body)
}