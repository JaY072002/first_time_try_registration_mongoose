const mongoose = require('mongoose')



const AdminSchema = new mongoose.Schema({
    email: {
        type: String,
        required: true,
        // unique: true
    },
    password: {
        type: String,
        required: true
    }
})

const admin = mongoose.model('admin', AdminSchema)

const adminCheck = async (data) => {
    try {
        const result = await admin.find();
        console.log(result);
    } catch (err) {
        console.log(err);
    }
}

module.exports = adminCheck
