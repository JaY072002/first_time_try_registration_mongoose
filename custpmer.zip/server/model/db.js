// database connection stuff

const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/Cust_registration', { useNewURLParser: true, useUnifiedTopology: true }).then(() => {
    console.log('Connected to mongodb');
}).catch((err) => {
    console.log(err);
})

