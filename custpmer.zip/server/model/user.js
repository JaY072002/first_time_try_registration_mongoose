// schema and collection of user
// const valitation = require('validation');
const mongoose = require('mongoose');
require('mongodb')
// const res = require('express/lib/response');

const userSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        // unique: true
    },
    password: {
        type: String,
        required: true
    }
})

// creating model of the userschema

const User = new mongoose.model('User', userSchema);


const insertData = async (data) => {
    try {


        const result = new User(data);
        const userSaved = await result.save();


    } catch (err) {
        console.log(err);
    }
}

const checkUser = async (data) => {
    try {
        const email = data.email;
        const query = { email: email }
        const result = await User.find(query)

        return result;

    } catch (err) {
        console.log(err);
    }
}

const loginUser = async (data) => {
    try {

        const dbdata = await User.find(data)
        return dbdata
    } catch (err) {
        console.log(err);
    }
}

module.exports = {
    insertData,
    checkUser,
    loginUser
}