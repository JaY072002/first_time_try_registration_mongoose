const router = require('express').Router();
const userRouteController = require('../controller/userRouteController')

router.get('/', userRouteController.homePageRender)

router.post('/register', userRouteController.postData)

router.get('/login', userRouteController.loginPageRender)

router.post('/login', userRouteController.userLogin)

router.get('/admin', userRouteController.adminPage)

router.post('/admin', userRouteController.adminPostHandle)


module.exports = router;